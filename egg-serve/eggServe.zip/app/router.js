"use strict";

// const auth = require("./middleware/auth");

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = (app) => {
  const { router, controller, jwt } = app;
  // console.log('jwt',jwt);
  const baseRouter = app.config.baseRouter; //
  router.get("/", controller.home.index);
  // 创建用户信息
  router.post(baseRouter + "/adminCreate", controller.login.adminCreate);
  // 登录
  router.post(baseRouter + "/login", controller.login.adminLogin);
  // 退出登录
  router.post(baseRouter + "/logout", controller.login.adminLogout);

  // 创建就业信息
  router.post(baseRouter + "/createInformation", controller.information.create);
  // 查询学员列表页
  router.post(baseRouter + "/findInformation", controller.information.findAll);
  // 删除
  router.post(
    baseRouter + "/removeInformation",
    controller.information.removeOneInformation
  );
  // 修改
  router.post(
    baseRouter + "/updateOneInformation",
    controller.information.updateOneInformation
  );
  // 获取表单回显数据
  router.get(
    baseRouter + "/echoOneInformationData/:phone",
    // jwt,
    controller.information.echoOneInformationData
  );

  // 就业统计
  router.get(
    baseRouter + "/employmentStatisticsList/:currencyType",
    controller.statisticsInformation.findAll
  );
  // 就业统计详情
  router.post(
    baseRouter + "/findDetailData",
    controller.statisticsInformation.findDetailData
  );
  // 信息列表页
  // router.post("/information", controller.information);




  // 查询所有用户
  router.post(
    baseRouter + "/findAllUser",
    controller.login.findAllUser
  );
  // 删除
  router.get(baseRouter + "/removeOneUser/:id", controller.login.adminRemove);
  // 用户表单回显数据
  router.get(
    baseRouter + "/echoOneUserData/:userName",
    controller.login.echoOneUserData
  );
  // 修改数据
  router.post(
    baseRouter + "/updateUser",
    controller.login.updateUser
  );
};
