// This file is created by egg-ts-helper@1.34.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportInformation = require('../../../app/controller/information');
import ExportLogin = require('../../../app/controller/login');
import ExportStatisticsInformation = require('../../../app/controller/statisticsInformation');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    information: ExportInformation;
    login: ExportLogin;
    statisticsInformation: ExportStatisticsInformation;
  }
}
