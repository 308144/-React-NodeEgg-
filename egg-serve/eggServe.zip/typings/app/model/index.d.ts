// This file is created by egg-ts-helper@1.34.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/model/admin');
import ExportEnterprise = require('../../../app/model/enterprise');
import ExportInformation = require('../../../app/model/information');
import ExportPost = require('../../../app/model/post');
import ExportSpecialized = require('../../../app/model/specialized');

declare module 'egg' {
  interface IModel {
    Admin: ReturnType<typeof ExportAdmin>;
    Enterprise: ReturnType<typeof ExportEnterprise>;
    Information: ReturnType<typeof ExportInformation>;
    Post: ReturnType<typeof ExportPost>;
    Specialized: ReturnType<typeof ExportSpecialized>;
  }
}
