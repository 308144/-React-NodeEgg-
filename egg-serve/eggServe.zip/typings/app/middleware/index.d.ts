// This file is created by egg-ts-helper@1.34.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCros = require('../../../app/middleware/cros');
import ExportErrorHandler = require('../../../app/middleware/error_handler');

declare module 'egg' {
  interface IMiddleware {
    cros: typeof ExportCros;
    errorHandler: typeof ExportErrorHandler;
  }
}
